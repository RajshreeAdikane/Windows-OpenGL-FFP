#pragma once // I am as developer if this file multiple times include by me but you have to include once

#define MY_ICON 101

#define IDBITMAP_MARBLE 102


